#!/usr/bin/env python3
"""
Interfaz web básica para osint-recon (Flask).

Ofrece un formulario simple para lanzar una investigación y muestra el reporte
HTML embebido y los enlaces de descarga (JSON / grafo / GraphML).

Pensada para uso LOCAL del analista. Se vincula por defecto a 127.0.0.1 y pide
confirmar la autorización antes de ejecutar. No la expongas a Internet.

Ejecución:
    cd osint-recon
    python3 web/app.py           # -> http://127.0.0.1:5000
"""

from __future__ import annotations

import os
import sys
from datetime import datetime

# Añade la raíz del proyecto al path para importar osintlib.
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from flask import Flask, request, render_template, send_from_directory, abort

from osintlib.graphexport import export_all
from osintlib.orchestrator import Orchestrator
from osintlib.report import write_html, write_json

app = Flask(__name__)
OUTPUT_DIR = os.path.join(ROOT, "salidas")
os.makedirs(OUTPUT_DIR, exist_ok=True)


def _load_config():
    import configparser
    cfg = {"api_keys": {}, "settings": {}}
    path = os.path.join(ROOT, "config.ini")
    if os.path.exists(path):
        parser = configparser.ConfigParser()
        parser.read(path, encoding="utf-8")
        for section in parser.sections():
            cfg.setdefault(section, {})
            cfg[section].update(dict(parser.items(section)))
    return cfg


@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "GET":
        return render_template("index.html")

    # POST: lanzar investigación.
    if not request.form.get("authorized"):
        return render_template("index.html",
                               error="Debes confirmar que tienes autorización.")

    targets = []
    for field in ("name", "email", "username", "phone", "domain"):
        val = (request.form.get(field) or "").strip()
        if val:
            targets.append(val)
    if not targets:
        return render_template("index.html", error="Indica al menos un objetivo.")

    enabled = request.form.getlist("modules") or None
    orch = Orchestrator(config=_load_config(), enabled_modules=enabled)
    run = orch.run(targets)

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    base = "web_" + stamp
    produced = export_all(run.graph, OUTPUT_DIR, base + "_grafo",
                          title="Grafo OSINT: " + ", ".join(targets))
    json_path = write_json(run, os.path.join(OUTPUT_DIR, base + ".json"))
    html_path = write_html(run, os.path.join(OUTPUT_DIR, base + ".html"),
                           graph_png_path=produced.get("png"))

    with open(html_path, "r", encoding="utf-8") as fh:
        report_html = fh.read()

    return render_template(
        "index.html",
        report_html=report_html,
        downloads={
            "JSON": os.path.basename(json_path),
            "HTML": os.path.basename(html_path),
            "GraphML (Maltego)": os.path.basename(produced["graphml"]),
            "DOT": os.path.basename(produced["dot"]),
            "PNG": os.path.basename(produced["png"]) if produced.get("png") else None,
        },
        targets=targets,
    )


@app.route("/download/<path:fname>")
def download(fname):
    # Evita traversal: solo nombres de fichero dentro de OUTPUT_DIR.
    if "/" in fname or ".." in fname:
        abort(400)
    return send_from_directory(OUTPUT_DIR, fname, as_attachment=True)


if __name__ == "__main__":
    # Bind a localhost por seguridad. Cambia host solo si sabes lo que haces.
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", 5000)), debug=False)

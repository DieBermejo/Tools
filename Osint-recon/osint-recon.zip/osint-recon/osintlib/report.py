"""
Generación de reportes estructurados.

Produce dos formatos a partir de un objeto Run:
  - JSON : volcado completo y legible por máquina (grafo + resultados por módulo).
  - HTML : informe autocontenido (CSS en línea, grafo PNG embebido en base64) con
           resumen, hallazgos por módulo, tablas de entidades/relaciones y un aviso
           destacado de uso autorizado.

El PDF se puede obtener imprimiendo el HTML a PDF desde el navegador (Ctrl+P), lo
que evita dependencias binarias pesadas.
"""

from __future__ import annotations

import base64
import json
import os
from datetime import datetime
from typing import Any, Dict, Optional

from jinja2 import Template

from .orchestrator import Run


def write_json(run: Run, path: str) -> str:
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(run.to_dict(), fh, ensure_ascii=False, indent=2, default=str)
    return path


_HTML_TEMPLATE = Template(r"""<!doctype html>
<html lang="es"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Reporte OSINT — {{ targets_str }}</title>
<style>
  :root{--bg:#0f172a;--panel:#1e293b;--panel2:#273449;--ink:#e2e8f0;--muted:#94a3b8;
        --accent:#38bdf8;--ok:#22c55e;--warn:#f59e0b;--err:#ef4444;--line:#334155;}
  *{box-sizing:border-box} body{margin:0;background:#0b1220;color:var(--ink);
    font:15px/1.55 -apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;}
  .wrap{max-width:1040px;margin:0 auto;padding:28px 18px 80px;}
  header{border-bottom:1px solid var(--line);padding-bottom:16px;margin-bottom:22px;}
  h1{font-size:24px;margin:0 0 4px;letter-spacing:.2px;}
  h2{font-size:18px;margin:30px 0 12px;border-left:3px solid var(--accent);padding-left:10px;}
  .sub{color:var(--muted);font-size:13px;}
  .legal{background:#422006;border:1px solid var(--warn);color:#fde68a;border-radius:10px;
    padding:12px 14px;margin:16px 0;font-size:13px;}
  .cards{display:flex;flex-wrap:wrap;gap:12px;margin:8px 0 4px;}
  .card{background:var(--panel);border:1px solid var(--line);border-radius:12px;
    padding:14px 16px;min-width:130px;flex:1;}
  .card .n{font-size:26px;font-weight:700;color:var(--accent);}
  .card .l{font-size:12px;color:var(--muted);text-transform:uppercase;letter-spacing:.5px;}
  table{width:100%;border-collapse:collapse;margin:10px 0;font-size:13.5px;}
  th,td{text-align:left;padding:8px 10px;border-bottom:1px solid var(--line);vertical-align:top;}
  th{color:var(--muted);font-weight:600;font-size:12px;text-transform:uppercase;letter-spacing:.4px;}
  tr:hover td{background:#16233a;}
  .badge{display:inline-block;padding:2px 8px;border-radius:999px;font-size:11px;font-weight:600;}
  .b-ok{background:#064e3b;color:#6ee7b7;} .b-skip{background:#374151;color:#d1d5db;}
  .b-err{background:#4c0519;color:#fda4af;} .b-ni{background:#422006;color:#fcd34d;}
  .mod{background:var(--panel);border:1px solid var(--line);border-radius:12px;
    padding:14px 16px;margin:10px 0;}
  .mod h3{margin:0 0 4px;font-size:15px;} .mod .msg{color:var(--muted);font-size:13px;}
  .tag{display:inline-block;background:var(--panel2);border:1px solid var(--line);
    border-radius:6px;padding:1px 7px;margin:2px 3px 2px 0;font-size:12px;color:#cbd5e1;}
  .graph{background:#fff;border-radius:12px;padding:10px;text-align:center;margin:12px 0;}
  .graph img{max-width:100%;height:auto;}
  code{background:#0b1220;border:1px solid var(--line);border-radius:5px;padding:1px 5px;font-size:12.5px;}
  footer{margin-top:40px;color:var(--muted);font-size:12px;border-top:1px solid var(--line);padding-top:14px;}
  a{color:var(--accent);}
  details{margin:6px 0;} summary{cursor:pointer;color:var(--muted);}
</style></head><body><div class="wrap">

<header>
  <h1>🔎 Reporte OSINT</h1>
  <div class="sub">Objetivos: <strong>{{ targets_str }}</strong> ·
    Generado: {{ generated }} · Motor osint-recon v{{ version }}</div>
</header>

<div class="legal">
  <strong>⚠️ Uso autorizado únicamente.</strong> Este informe recopila información
  de fuentes públicas (OSINT). Úsalo solo sobre objetivos para los que tengas
  autorización explícita (auditorías, investigación propia, consentimiento del
  titular). El uso contra terceros sin permiso puede ser ilegal y vulnerar la
  normativa de protección de datos (p. ej. RGPD).
</div>

<div class="cards">
  {% for k, v in stat_cards %}
  <div class="card"><div class="n">{{ v }}</div><div class="l">{{ k }}</div></div>
  {% endfor %}
</div>

{% if graph_b64 %}
<h2>Grafo de relaciones</h2>
<div class="graph"><img alt="Grafo de relaciones OSINT" src="data:image/png;base64,{{ graph_b64 }}"></div>
<div class="sub">Exportable también a <code>.graphml</code> (Maltego/yEd/Gephi) y <code>.dot</code> (Graphviz).</div>
{% endif %}

<h2>Resultados por módulo</h2>
{% for r in results %}
<div class="mod">
  <h3>{{ r.module }}
    {% if r.status=='ok' %}<span class="badge b-ok">OK</span>
    {% elif r.status=='skipped' %}<span class="badge b-skip">OMITIDO</span>
    {% elif r.status=='not_installed' %}<span class="badge b-ni">NO INSTALADO</span>
    {% else %}<span class="badge b-err">ERROR</span>{% endif %}
    <span class="sub">· {{ r.target }} · {{ r.elapsed_s }}s · +{{ r.entities_added }} ent / +{{ r.relations_added }} rel</span>
  </h3>
  <div class="msg">{{ r.message }}</div>
  {% if r.findings %}
  <details open><summary>{{ r.findings|length }} hallazgo(s)</summary>
  <table><tbody>
  {% for f in r.findings %}
    <tr>{% for k, v in f.items() %}<td><strong>{{ k }}:</strong> {{ v }}</td>{% endfor %}</tr>
  {% endfor %}
  </tbody></table></details>
  {% endif %}
</div>
{% endfor %}

<h2>Entidades ({{ entities|length }})</h2>
<table><thead><tr><th>Tipo</th><th>Valor</th><th>Fuentes</th><th>Conf.</th></tr></thead><tbody>
{% for e in entities %}
  <tr><td><span class="tag">{{ e.etype }}</span></td>
      <td>{{ e.label }}</td>
      <td>{% for s in e.sources %}<span class="tag">{{ s }}</span>{% endfor %}</td>
      <td>{{ '%.2f'|format(e.confidence) }}</td></tr>
{% endfor %}
</tbody></table>

<h2>Relaciones ({{ relations|length }})</h2>
<table><thead><tr><th>Origen</th><th>Relación</th><th>Destino</th></tr></thead><tbody>
{% for rel in relations %}
  <tr><td>{{ id2label[rel.src_id] }}</td><td><span class="tag">{{ rel.label }}</span></td>
      <td>{{ id2label[rel.dst_id] }}</td></tr>
{% endfor %}
</tbody></table>

<footer>
  Informe generado automáticamente por <strong>osint-recon</strong>. Los datos
  provienen de fuentes públicas en el momento de la consulta y pueden contener
  falsos positivos (p. ej. perfiles homónimos). Para obtener PDF: imprime esta
  página (Ctrl/Cmd+P → Guardar como PDF).
</footer>
</div></body></html>""")


def write_html(run: Run, path: str, graph_png_path: Optional[str] = None) -> str:
    graph_b64 = None
    if graph_png_path and os.path.exists(graph_png_path):
        with open(graph_png_path, "rb") as fh:
            graph_b64 = base64.b64encode(fh.read()).decode("ascii")

    gdict = run.graph.to_dict()
    stats = gdict["stats"]
    id2label = {e["id"]: e["label"] for e in gdict["entities"]}

    # Tarjetas de resumen (tipos principales).
    order = ["_entidades_total", "_relaciones", "email", "username", "social_profile",
             "domain", "ip", "breach"]
    labels = {"_entidades_total": "Entidades", "_relaciones": "Relaciones",
              "email": "Emails", "username": "Usernames", "social_profile": "Perfiles",
              "domain": "Dominios", "ip": "IPs", "breach": "Brechas"}
    stat_cards = [(labels.get(k, k), stats.get(k, 0)) for k in order if stats.get(k, 0)]

    html = _HTML_TEMPLATE.render(
        targets_str=", ".join(v for _, v in run.targets),
        generated=datetime.now().strftime("%Y-%m-%d %H:%M"),
        version="1.0.0",
        stat_cards=stat_cards,
        graph_b64=graph_b64,
        results=[r.to_dict() for r in run.results],
        entities=gdict["entities"],
        relations=gdict["relations"],
        id2label=id2label,
    )
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(html)
    return path

"""
Módulo: brechas de datos GRATIS (XposedOrNot).

Alternativa sin coste a Have I Been Pwned. Usa la API pública de XposedOrNot,
que NO requiere clave, para saber en qué brechas aparece un email.

Endpoints (documentados en https://xposedornot.com/api_doc):
  - GET /v1/check-email/{email}      -> lista de nombres de brechas (rápido)
  - GET /v1/breach-analytics?email=  -> detalle por brecha (fechas, datos expuestos...)

Límites del tier gratuito (por IP): 2 req/s, 25 req/hora, 100 req/día. Por eso el
módulo hace como mucho 2 peticiones por email y respeta un pequeño retardo.

Cada brecha se añade como entidad 'breach' y se enlaza al email con 'expuesto_en',
igual que el módulo de pago, de modo que ambos son intercambiables en el grafo.
"""

from __future__ import annotations

import time

from ..entity import Entity, Graph
from .base import BaseModule, Context, ModuleResult

CHECK_URL = "https://api.xposedornot.com/v1/check-email/{email}"
ANALYTICS_URL = "https://api.xposedornot.com/v1/breach-analytics"


class BreachesFreeModule(BaseModule):
    name = "breaches_free"
    description = "Brechas de datos públicas de un email vía XposedOrNot (gratis, sin clave)"
    accepts = ("email",)

    def run(self, target_type: str, target_value: str, graph: Graph,
            ctx: Context) -> ModuleResult:
        res = ModuleResult(module=self.name, target=target_value)
        email = target_value

        email_ent = graph.get("email", email) or graph.add_entity(
            Entity("email", email, sources=[self.name])
        )

        # --- 1) Comprobación básica: ¿hay brechas? ---------------------------
        try:
            r = ctx.session.get(CHECK_URL.format(email=email), timeout=20)
        except Exception as exc:
            res.status = "error"
            res.message = f"Error de red consultando XposedOrNot: {exc}"
            return res

        if r.status_code == 404:
            res.message = "Sin brechas registradas para este email (HTTP 404)."
            return res
        if r.status_code == 429:
            res.status = "error"
            res.message = ("Límite de peticiones de XposedOrNot alcanzado "
                           "(2/s, 25/h, 100/día). Reintenta más tarde.")
            return res
        if r.status_code != 200:
            res.status = "error"
            res.message = f"Respuesta inesperada de XposedOrNot (HTTP {r.status_code})."
            return res

        try:
            data = r.json()
        except ValueError:
            res.status = "error"
            res.message = "No se pudo parsear la respuesta de XposedOrNot."
            return res

        # El endpoint devuelve {"Error":"Not found", ...} cuando no hay nada.
        if isinstance(data, dict) and data.get("Error"):
            res.message = "Sin brechas registradas para este email."
            return res

        # 'breaches' llega como lista que contiene una lista de nombres.
        raw = data.get("breaches") if isinstance(data, dict) else None
        breach_names = []
        if isinstance(raw, list):
            for item in raw:
                if isinstance(item, list):
                    breach_names.extend(item)
                elif isinstance(item, str):
                    breach_names.append(item)
        breach_names = [b for b in breach_names if b]

        if not breach_names:
            res.message = "Sin brechas registradas para este email."
            return res

        # --- 2) Detalle por brecha (una sola petición extra) -----------------
        details = {}
        time.sleep(0.6)  # respeta el límite de 2 req/s
        try:
            ra = ctx.session.get(ANALYTICS_URL, params={"email": email}, timeout=25)
            if ra.status_code == 200:
                adata = ra.json()
                exposed = (adata or {}).get("ExposedBreaches") or {}
                for d in (exposed.get("breaches_details") or []):
                    if isinstance(d, dict) and d.get("breach"):
                        details[d["breach"]] = d
        except Exception:
            # El detalle es opcional; si falla, seguimos con los nombres.
            pass

        for name in breach_names:
            d = details.get(name, {})
            breach_ent = graph.add_entity(Entity(
                etype="breach",
                value=name,
                label=f"Brecha: {name}",
                sources=[self.name],
                confidence=0.85 if d.get("verified") else 0.6,
                attrs={
                    "fuente_api": "XposedOrNot",
                    "dominio": d.get("domain"),
                    "fecha": d.get("xposed_date"),
                    "cuentas_afectadas": d.get("xposed_records"),
                    "verificada": d.get("verified"),
                    "datos_expuestos": d.get("xposed_data"),
                    "descripcion": (d.get("details") or "")[:300] or None,
                },
            ))
            graph.add_relation(email_ent, breach_ent, "expuesto_en", source=self.name)
            res.findings.append({
                "brecha": name,
                "fecha": d.get("xposed_date"),
                "datos_expuestos": d.get("xposed_data"),
            })

        res.message = f"{len(breach_names)} brecha(s) encontradas (XposedOrNot, gratis)."
        res.meta = {"con_detalle": len(details)}
        return res
